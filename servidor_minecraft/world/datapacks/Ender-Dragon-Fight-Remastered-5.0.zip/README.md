# Ender Dragon Fight Remastered
![Modrinth Downloads](https://img.shields.io/modrinth/dt/edf-remastered)

An up in the difficulty of the final boss fight of Minecraft.

Music by [Solunary](https://www.youtube.com/watch?v=GAW5tuC83mE) and [DM Dokuro](https://www.youtube.com/watch?v=3UtURionlvU)
